/**
 * PIC10F322 Hardware initialization.
 * @file   hardware.h
 * @author Thomas Reidemeister <treideme@gmail.com>
 */
#ifndef _hardware_h_
#define _hardware_h_

/******************************************************************************\
 * Clock and Oscillator Configuration                                         *
\******************************************************************************/
#define INIT_CLKRCON             \
    0b00000000 /**< REFERENCE CLOCK CONTROL REGISTER @verbatim
      00000000 = reset
      x|xxxxxx
       +-------- CLKROE = 0     : Reference Clock output disabled

  @endverbatim */

#define INIT_OSCCON              \
    0b01110000 /**< OSCILLATOR CONTROL REGISTER @verbatim
      01100000 = reset
      x||||x||
       |||| |+-- HFIOFS = R/O   : High-Frequency Internal Oscillator Stable bit
       |||| +--- LFIOFR = R/O   : Low-Frequency Internal Oscillator Ready bit
       |||+----- HFIOFR = R/O   : High-Frequency Internal Oscillator Ready bit
       +++------ IRCF   = 0b111 : Frequency bit select (16MHz)

  @endverbatim */

#define SYS_FREQ        16000000L  ///< System Frequency
#define _XTAL_FREQ      SYS_FREQ   ///< System frequency used for delay_ms
#define FCY             SYS_FREQ/4 ///< Instructions per Second

/******************************************************************************\
 * Options Register                                                           *
\******************************************************************************/
#define INIT_OPTION_REG              \
    0b01011111 /**< REFERENCE CLOCK CONTROL REGISTER @verbatim
      11111111 = reset
      ||||||||
      |||||+++-- PS     = 0b111 : Prescaler Rate Select bits (256)
      ||||+----- PSA    = 1     : Prescaler HASno effect on the TMR0
      |||+------ T0SE   = 1     : Increment on high-to-low transition on T0CKI pin
      ||+------- T0CS   = 0     : TMR0 Clock Source is instruction cycle clock (FCY)
      |+-------- INTEDG = 1     : Interrupt on rising edge of INT pin
      +--------- WPUEN  = 0     : Weak pull-ups enabled by PORT latch values

  @endverbatim */


/******************************************************************************\
 * Function prototypes                                                        *
\******************************************************************************/

/**
 * Main entry point for hardware configuration.
 */
void EntryPoint(void);

#endif /* _hardware_h_ */