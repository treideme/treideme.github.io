/**
 * PIC10F322 Hardware initialization.
 * @file   hardware.c
 * @author Thomas Reidemeister <treideme@gmail.com>
 */
#include <xc.h>            /* XC8 General Include File */
#include "hardware.h"      /* For initialization constants */
#include "pins.h"          /* For pin configuration */

void EntryPoint(void) {
    /* Configure pins (note do this first to avoid reset transients) */
    ANSELA = INIT_ANSELA;
    TRISA  = INIT_TRISA;
    WPUA   = INIT_WPUA;
    
    /* Configure option bits (also affects pull-ups) */
    OPTION_REG = INIT_OPTION_REG;
    
    /* Configure oscillator */
    CLKRCON = INIT_CLKRCON;
    OSCCON  = INIT_OSCCON;
    
    /* Wait until oscillator is stable */
    while((OSCCON & 0b1001) != 0b1001);
    /*                           |xx|
                                 |  +-- High-frequency INTOSC stable
                                 +----- High-frequency INTOSC ready
     */
}

/******************************************************************************\
 * Interrupt Routine                                                          *
\******************************************************************************/

#ifndef _PIC12

/** Interrupt service routine.
 * Baseline devices don't have interrupts. Unfortunately the baseline detection
 * macro is named _PIC12 (regardless of device).  Baseline devices include some
 * PIC10's and PIC16's as well. 
 */
void __interrupt isr(void)
{
    /* This code stub shows general interrupt handling.  Note that these
    conditional statements are not handled within 3 seperate if blocks.
    Do not use a seperate if block for each interrupt flag to avoid run
    time errors. */

#if 0

    /* TODO Add interrupt routine code here. */

    /* Determine which flag generated the interrupt */
    if(<Interrupt Flag 1>)
    {
        <Interrupt Flag 1=0>; /* Clear Interrupt Flag 1 */
    }
    else if (<Interrupt Flag 2>)
    {
        <Interrupt Flag 2=0>; /* Clear Interrupt Flag 2 */
    }
    else
    {
        /* Unhandled interrupts */
    }

#endif

}
#endif