/**
 * PIC10F322 Main control loop.
 * @file   main.c
 * @author Thomas Reidemeister <treideme@gmail.com>
 */
#include <xc.h>            /* XC8 General Include File */
#include <stdint.h>        /* For uint8_t definition */
#include <stdbool.h>       /* For true/false definition */

#include "hardware.h"      /* System initialisation and interrupts */

/******************************************************************************\
 * User Global Variable Declaration                                           * 
\******************************************************************************/

/******************************************************************************\
 * Main Functions                                                             * 
\******************************************************************************/

/**
 * Main entry point for program.
 */
void main(void)
{
    EntryPoint();
    
    while(1){ 
        LATA2=1; 
        __delay_ms(500); 
        LATA2=0; 
        __delay_ms(500); 
    }
}

