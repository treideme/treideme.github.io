/**
 * PIC10F322 PIN Initialization.
 * @file   pins.h
 * @author Thomas Reidemeister <treideme@gmail.com>
 * @verbatim
                         PIC10F322
                        +---------+
                      1-+         +-8
                      2-+         +-7
                      3-+         +-6
                      4-+         +-5
                        +---------+
                          PDIP-8
 
    Pin Name            Connector     Function
      1 N/C
      2 V_DD
      3 RA2             LED_OUT       OUTPUT
      4 ICSPCLK/RA1 
      5 RA0/ICSPDAT
      6 N/C
      7 V_SS
      8 RA3/MCLR/V_PP
   @endverbatim
 */
#ifndef _pins_h_
#define _pins_h_

#define INIT_TRISA             \
    0b00000011 /**< PORTA TRI-STATE REGISTER @verbatim
      00001111 = reset
      xxxxx|||
           ||+-- TRISA0 = 1 : RA0 output driver disabled
           |+--- TRISA1 = 1 : RA1 output driver disabled
           +---- TRISA2 = 0 : RA2 output driver enabled

  @endverbatim */

#define INIT_ANSELA             \
    0b00000000 /**< PORTA ANALOG SELECT REGISTER @verbatim
      00000111 = reset
      xxxxx|||
           ||+-- ANSA0  = 0 : RA0 is digital I/O
           |+--- ANSA1  = 0 : RA1 is digital I/O
           +---- ANSA2  = 0 : RA2 is digital I/O

  @endverbatim */

#define INIT_WPUA              \
    0b00001011 /**< WEAK PULL-UP PORTA REGISTER @verbatim
      00001111 = reset
      xxxx||||
          |||+-- WPUA0  = 1 : RA0 is pulled up
          ||+--- WPUA1  = 1 : RA1 is pulled up
          |+---- WPUA2  = 0 : RA2 is not pulled up
          +----- WPUA3  = 1 : RA3 is pulled up

  @endverbatim */



#endif /* _pins_h_ */