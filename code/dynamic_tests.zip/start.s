/**
 * @author: Copyright 2009,2010 Thomas Reidemeister
 * @date: 2009.12.14
 * @file: start.s
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
    .comm old_stack,4
    .comm main_stack,1024

    .even

    move.l %a7,old_stack
    move.l #main_stack+1024, %a7

    jsr main
	
    move.l old_stack,%a7

    move.l %d0, %d7

    move.l #0,%d0
    trap #15
